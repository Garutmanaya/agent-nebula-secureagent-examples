/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {BaseVersionAdapter, ProtocolVersion} from './base.js';
import {InternalComponentPayload, InternalOperation} from '../operations.js';
import {A2uiMessageSchema} from '../../v0_9/schema/server-to-client.js';

/**
 * Protocol version adapter for specification v0.9 and v0.9.1.
 */
export class V0Point9Adapter extends BaseVersionAdapter {
  readonly version: ProtocolVersion = 'v0.9';
  protected readonly schema = A2uiMessageSchema;

  override get compatibleCatalogVersions(): ReadonlySet<string> {
    return new Set(['0.9', '0.9.1']);
  }

  protected getNativeActionKeys(): string[] {
    return ['createSurface', 'updateComponents', 'updateDataModel', 'deleteSurface'];
  }

  protected extractOperationsFromObject(msgObj: Record<string, unknown>): InternalOperation[] {
    const ops: InternalOperation[] = [];
    if ('createSurface' in msgObj) {
      const cs = msgObj.createSurface as Record<string, unknown>;
      ops.push({
        type: 'createSurface',
        surfaceId: String(cs?.surfaceId || ''),
        catalogId: typeof cs?.catalogId === 'string' ? cs.catalogId : undefined,
        theme: cs?.theme,
        sendDataModel: Boolean(cs?.sendDataModel),
        components: Array.isArray(cs?.components)
          ? (cs.components as InternalComponentPayload[])
          : undefined,
        dataModel:
          cs?.dataModel && typeof cs.dataModel === 'object' && !Array.isArray(cs.dataModel)
            ? (cs.dataModel as Record<string, unknown>)
            : undefined,
        version: typeof msgObj.version === 'string' ? msgObj.version : this.version,
      });
    }
    if ('updateComponents' in msgObj) {
      const uc = msgObj.updateComponents as Record<string, unknown>;
      ops.push({
        type: 'updateComponents',
        surfaceId: String(uc?.surfaceId || ''),
        components: Array.isArray(uc?.components) ? uc.components : [],
      });
    }
    if ('updateDataModel' in msgObj) {
      const ud = msgObj.updateDataModel as Record<string, unknown>;
      ops.push({
        type: 'updateDataModel',
        surfaceId: String(ud?.surfaceId || ''),
        path: typeof ud?.path === 'string' ? ud.path : undefined,
        value: ud?.value,
      });
    }
    if ('deleteSurface' in msgObj) {
      const ds = msgObj.deleteSurface as Record<string, unknown>;
      ops.push({
        type: 'deleteSurface',
        surfaceId: String(ds?.surfaceId || ''),
      });
    }
    return ops;
  }
}
