/*
 * Copyright 2024 Google LLC
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

import {createContext} from '@lit/context';

import type {MarkdownRenderer} from '../../../rendering/markdown.js';

export type {
  MarkdownRenderer,
  MarkdownRendererOptions,
  MarkdownRendererTagClassMap,
} from '../../../rendering/markdown.js';

/**
 * The markdown renderer context.
 *
 * This is used by the Text widget to render markdown content.
 */
export const markdown = createContext<MarkdownRenderer | undefined>(Symbol.for('A2UIMarkdown'));
