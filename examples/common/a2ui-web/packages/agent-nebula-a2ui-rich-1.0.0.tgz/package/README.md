# Agent Nebula A2UI Rich Catalog

Reusable, agent-driven visual vocabulary for A2UI v1.0 Candidate.

Catalog ID: `https://agentnebula.ai/catalogs/a2ui/rich/v1/catalog.json`

## Boundary

Use the official A2UI Basic Catalog whenever it can express the UI. Add a Rich Catalog component only for a reusable semantic visualization that Basic does not provide. Applications must not add agent-specific presentation logic to their React hosts.

Each component is an independent plugin directory containing `api.js` and `renderer.jsx`. `npm run generate` discovers component directories and generates the runtime registry and standards-compliant catalog JSON. Adding a component does not require editing existing components or a central handwritten registry.

Initial groups: information, results/decisions, business intelligence, itinerary, and spatial selection.
