/** Shared A2UI v1.0 React binding adapter for Rich Catalog components. */
import {useEffect, useMemo, useState} from "react";
import {ComponentContext, GenericBinder} from "@a2ui/web_core/rendering";

/** Resolve official A2UI data bindings and dispatch catalog actions. */
export function useRichComponent(surface, component, basePath = "/") {
  const context = useMemo(() => new ComponentContext(surface, component.id, basePath), [surface, component, basePath]);
  const binder = useMemo(() => {
    const api = component.catalog?.components.get(component.type) ?? surface.catalog.components.get(component.type);
    return api ? new GenericBinder(context, api.schema) : null;
  }, [surface, component, context]);
  const [properties, setProperties] = useState(() => binder?.snapshot ?? component.properties ?? {});

  useEffect(() => {
    if (!binder) { setProperties(component.properties ?? {}); return undefined; }
    setProperties(binder.snapshot);
    const subscription = binder.subscribe((next) => setProperties({...next}));
    return () => { subscription.unsubscribe(); binder.dispose(); };
  }, [binder, component]);

  /**
   * Dispatch an ActionSchema through the official A2UI ComponentContext.
   *
   * GenericBinder resolves top-level ActionSchema properties into callbacks.
   * Actions nested inside catalog-owned arrays/objects remain values owned by
   * the custom component, so the renderer must dispatch those values through
   * ComponentContext rather than treating the raw ActionSchema as a React
   * event handler. ComponentContext performs the standard A2UI action/context
   * resolution and forwards the resulting renderer-to-agent action.
   */
  const dispatchAction = (action) => context.dispatchAction(action);

  return {properties: properties ?? {}, dispatchAction};

}
