/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamic} from "../../../schema.js"; const slice=z.object({label:z.string(),value:z.number().nonnegative()}).strict(); export const api={name:"DonutChart",schema:z.object({title:z.string(),data:dynamic(z.array(slice).min(1)),centerLabel:z.string().optional()}).strict()};
