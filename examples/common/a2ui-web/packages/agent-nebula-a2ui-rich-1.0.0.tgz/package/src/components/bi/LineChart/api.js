/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamic} from "../../../schema.js"; const point=z.object({label:z.string(),value:z.number()}).strict(); export const api={name:"LineChart",schema:z.object({title:z.string(),subtitle:z.string().optional(),data:dynamic(z.array(point).min(2)),unit:z.string().optional()}).strict()};
