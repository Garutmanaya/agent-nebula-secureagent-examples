/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamic} from "../../../schema.js"; const item=z.object({label:z.string(),value:z.union([z.string(),z.number(),z.boolean()]),icon:z.string().optional()}).strict(); export const api={name:"KeyValueGroup",schema:z.object({title:z.string().optional(),items:dynamic(z.array(item))}).strict()};
