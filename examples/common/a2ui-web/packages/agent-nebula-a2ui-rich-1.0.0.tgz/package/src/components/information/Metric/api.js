/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamicNumber,dynamicString} from "../../../schema.js";
export const api={name:"Metric",schema:z.object({label:dynamicString,value:z.union([dynamicString,dynamicNumber]),unit:dynamicString.optional(),trend:z.enum(["up","down","flat"]).optional(),trendLabel:dynamicString.optional()}).strict()};
