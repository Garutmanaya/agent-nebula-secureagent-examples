/** Trusted React renderer for this Rich Catalog component. */
import React from "react"; import {useRichComponent} from "../../../binding.js";
export function Renderer({surface,component,basePath="/"}){const {properties:p}=useRichComponent(surface,component,basePath);return <article className="anu-rich-metric"><small>{p.label}</small><strong>{p.value}{p.unit&&<em>{p.unit}</em>}</strong>{p.trendLabel&&<span className={`trend-${p.trend}`}>{p.trend==="up"?"↑":p.trend==="down"?"↓":"→"} {p.trendLabel}</span>}</article>}
