/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamic} from "../../../schema.js";
const item=z.object({label:z.string(),value:z.union([z.string(),z.number()]),unit:z.string().optional(),status:z.enum(["info","success","warning","error","neutral","pending"]).optional()}).strict(); export const api={name:"MetricGroup",schema:z.object({title:z.string().optional(),metrics:dynamic(z.array(item).min(1))}).strict()};
