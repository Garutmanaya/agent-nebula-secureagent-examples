/** Trusted React renderer for this Rich Catalog component. */
import React from "react"; import {useRichComponent} from "../../../binding.js";
export function Renderer({surface,component,basePath="/"}){const {properties:p}=useRichComponent(surface,component,basePath);return <section className="anu-rich-metric-group">{p.title&&<h3>{p.title}</h3>}<div>{(p.metrics??[]).map((m,i)=><article key={`${m.label}-${i}`}><small>{m.label}</small><strong>{m.value}{m.unit&&<em>{m.unit}</em>}</strong></article>)}</div></section>}
