/** A2UI v1.0 component schema. */
import {z} from "zod"; import {dynamicString, statusSchema} from "../../../schema.js";
export const api={name:"StatusBadge",schema:z.object({label:dynamicString,status:statusSchema,icon:dynamicString.optional()}).strict()};
