/** Trusted React renderer for this Rich Catalog component. */
import React from "react"; import {useRichComponent} from "../../../binding.js";
export function Renderer({surface,component,basePath="/"}){const {properties:p}=useRichComponent(surface,component,basePath);return <span className={`anu-rich-status anu-rich-status-${p.status}`}><span aria-hidden="true">{p.icon??"●"}</span>{p.label}</span>}
