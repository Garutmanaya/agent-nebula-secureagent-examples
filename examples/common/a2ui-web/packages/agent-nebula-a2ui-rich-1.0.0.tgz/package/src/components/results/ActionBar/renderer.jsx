/** Trusted React renderer for the Rich Catalog ActionBar component. */
import React from "react";
import {useRichComponent} from "../../../binding.js";

/** Render ActionBar actions resolved by the official A2UI GenericBinder. */
export function Renderer({surface, component, basePath = "/"}) {
  const {properties: p} = useRichComponent(surface, component, basePath);

  return (
    <div className={`anu-rich-actions align-${p.align}`}>
      {(p.actions ?? []).map((action) => (
        <button
          key={action.id}
          type="button"
          className={`variant-${action.variant}`}
          disabled={action.disabled}
          onClick={action.action}
        >
          {action.label}
        </button>
      ))}
    </div>
  );
}
