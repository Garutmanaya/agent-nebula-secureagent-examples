/** A2UI v1.0 schema for a reusable detail/summary panel. */
import {z} from "zod";
import {dynamic} from "../../../schema.js";

const item = z.object({label: z.string(), value: z.string()}).strict();

export const api = {
  name: "DetailPanel",
  schema: z.object({
    title: z.string(),
    subtitle: z.string().optional(),
    status: z.string().optional(),
    tone: z.enum(["neutral", "info", "success", "warning", "error"]).optional(),
    items: dynamic(z.array(item)).optional(),
    message: dynamic(z.string()).optional(),
  }).strict(),
};
