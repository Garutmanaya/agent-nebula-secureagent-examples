/** Trusted React renderer for the Rich Catalog DetailPanel component. */
import React from "react";
import {useRichComponent} from "../../../binding.js";

/** Render generic structured details with an optional semantic presentation tone. */
export function Renderer({surface, component, basePath = "/"}) {
  const {properties: p} = useRichComponent(surface, component, basePath);
  return <aside className={`anu-rich-detail tone-${p.tone ?? "neutral"}`}>
    <header>
      <div><h3>{p.title}</h3>{p.subtitle && <p>{p.subtitle}</p>}</div>
      {p.status && <span className="anu-rich-chip">{p.status}</span>}
    </header>
    <dl>{(p.items ?? []).map((m, i) => <React.Fragment key={`${m.label}-${i}`}><dt>{m.label}</dt><dd>{m.value}</dd></React.Fragment>)}</dl>
    {p.message && <strong className="anu-rich-message">{p.message}</strong>}
  </aside>;
}
