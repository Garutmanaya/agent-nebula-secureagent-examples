/** A2UI v1.0 schema for a reusable selectable result/comparison card. */
import {z} from "zod";
import {ActionSchema} from "@a2ui/web_core/v1_0";
import {dynamic, dynamicString} from "../../../schema.js";

const meta = z.object({label: z.string(), value: z.string()}).strict();

export const api = {
  name: "ResultCard",
  schema: z.object({
    resultId: dynamicString,
    title: dynamicString,
    subtitle: dynamicString.optional(),
    eyebrow: dynamicString.optional(),
    details: dynamic(z.array(meta)).optional(),
    status: dynamicString.optional(),
    primaryValue: dynamicString.optional(),
    secondaryValue: dynamicString.optional(),
    selected: z.boolean().optional(),
    recommended: z.boolean().optional(),
    actionLabel: dynamicString.optional(),
    selectAction: ActionSchema.optional(),
  }).strict(),
};
