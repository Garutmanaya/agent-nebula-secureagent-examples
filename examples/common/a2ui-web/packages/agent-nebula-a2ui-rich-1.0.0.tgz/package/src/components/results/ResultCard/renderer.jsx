/** Trusted React renderer for the Rich Catalog ResultCard component. */
import React from "react";
import {useRichComponent} from "../../../binding.js";

/** Render a compact generic result/choice without embedding domain semantics. */
export function Renderer({surface, component, basePath = "/"}) {
  const {properties: p} = useRichComponent(surface, component, basePath);
  const className = [
    "anu-rich-result-card",
    p.selectAction ? "interactive" : "",
    p.selected ? "selected" : "",
  ].filter(Boolean).join(" ");

  const body = <>
    <div className="result-card-main">
      <header>
        {p.eyebrow && <small>{p.eyebrow}</small>}
        <h3>{p.title}</h3>
        {p.subtitle && <p>{p.subtitle}</p>}
      </header>
      <div className="result-card-badges">
        {p.recommended && <span className="anu-rich-chip recommended">Recommended</span>}
        {p.status && <span className="anu-rich-chip">{p.status}</span>}
      </div>
      <dl>{(p.details ?? []).map((m, i) => <React.Fragment key={`${m.label}-${i}`}><dt>{m.label}</dt><dd>{m.value}</dd></React.Fragment>)}</dl>
    </div>
    {(p.primaryValue || p.secondaryValue || p.actionLabel) && <aside className="result-card-summary">
      {p.primaryValue && <strong>{p.primaryValue}</strong>}
      {p.secondaryValue && <small>{p.secondaryValue}</small>}
      {p.actionLabel && <span className="result-card-action">{p.selected ? "✓ " : ""}{p.actionLabel}</span>}
    </aside>}
  </>;

  return p.selectAction
    ? <button className={className} type="button" onClick={p.selectAction} aria-pressed={p.selected || undefined}>{body}</button>
    : <article className={className}>{body}</article>;
}
