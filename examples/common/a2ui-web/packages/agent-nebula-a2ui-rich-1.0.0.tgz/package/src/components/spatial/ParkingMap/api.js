/** A2UI v1.0 component schema. */
import {z} from "zod";
import {ActionSchema} from "@a2ui/web_core/v1_0";
import {dynamic} from "../../../schema.js";

const space = z.object({
  id: z.string(),
  level: z.string(),
  row: z.string(),
  column: z.number().int(),
  type: z.enum(["STANDARD", "EV", "ACCESSIBLE"]),
  status: z.enum(["AVAILABLE", "HELD", "RESERVED", "OUT_OF_SERVICE"]),
  selectAction: ActionSchema.optional(),
}).strict();

export const api = {
  name: "ParkingMap",
  schema: z.object({
    levels: dynamic(z.array(z.string()).min(1)),
    spaces: dynamic(z.array(space)),
    selectedSpaceId: dynamic(z.string().nullable()).optional(),
  }).strict(),
};
