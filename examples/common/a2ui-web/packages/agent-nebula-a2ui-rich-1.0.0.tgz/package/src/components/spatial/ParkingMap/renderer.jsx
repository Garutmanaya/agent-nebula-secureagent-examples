/** Trusted React renderer for the Rich Catalog ParkingMap component. */
import React, {useEffect, useState} from "react";
import {useRichComponent} from "../../../binding.js";

export function Renderer({surface, component, basePath = "/"}) {
  const {properties: p, dispatchAction} = useRichComponent(surface, component, basePath);
  const levels = p.levels ?? [];
  const [level, setLevel] = useState(levels[0] ?? "");

  useEffect(() => {
    if (!levels.includes(level)) setLevel(levels[0] ?? "");
  }, [levels, level]);

  const spaces = (p.spaces ?? []).filter((space) => space.level === level);
  const rows = [...new Set(spaces.map((space) => space.row))];

  return <section className="anu-rich-parking">
    <nav>
      {levels.map((candidate) => <button
        key={candidate}
        type="button"
        className={candidate === level ? "active" : ""}
        onClick={() => setLevel(candidate)}
      >{candidate}</button>)}
    </nav>
    <div className="parking-deck">
      {rows.map((row, index) => <React.Fragment key={row}>
        <div className="parking-row">
          <b>{row}</b>
          {spaces.filter((space) => space.row === row).map((space) => <button
            key={space.id}
            type="button"
            disabled={["RESERVED", "OUT_OF_SERVICE"].includes(space.status)}
            className={`bay ${space.status.toLowerCase()} ${space.id === p.selectedSpaceId ? "selected" : ""}`}
            title={`${space.id} · ${space.type} · ${space.status}`}
            onClick={space.selectAction ? () => dispatchAction(space.selectAction) : undefined}
          >
            <span>{space.id.split("-").at(-1)}</span>
            <i>{space.type === "EV" ? "⚡" : space.type === "ACCESSIBLE" ? "♿" : ""}</i>
          </button>)}
        </div>
        {index < rows.length - 1 && <div className="drive-aisle">← <span/> →</div>}
      </React.Fragment>)}
    </div>
  </section>;
}
