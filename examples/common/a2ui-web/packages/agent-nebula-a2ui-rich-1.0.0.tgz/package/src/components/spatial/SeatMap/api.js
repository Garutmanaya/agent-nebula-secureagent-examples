/** A2UI v1.0 component schema. */
import {z} from "zod";
import {ActionSchema} from "@a2ui/web_core/v1_0";
import {dynamic} from "../../../schema.js";

const seat = z.object({
  seat: z.string(),
  row: z.number().int().positive(),
  column: z.string(),
  cabin: z.string(),
  status: z.enum(["AVAILABLE", "HELD", "RESERVED", "UNAVAILABLE"]),
  selectAction: ActionSchema.optional(),
}).strict();

export const api = {
  name: "SeatMap",
  schema: z.object({
    aircraftType: dynamic(z.string()).optional(),
    aislesAfter: dynamic(z.array(z.string())).optional(),
    seats: dynamic(z.array(seat)),
    selectedSeat: dynamic(z.string().nullable()).optional(),
  }).strict(),
};
