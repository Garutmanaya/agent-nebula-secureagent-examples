/** Trusted React renderer for the Rich Catalog SeatMap component. */
import React from "react";
import {useRichComponent} from "../../../binding.js";

/**
 * Render an aircraft horizontally: travel direction runs left-to-right, while
 * seat letters are stacked vertically around the aisle for each numbered row.
 */
export function Renderer({surface, component, basePath = "/"}) {
  const {properties: p, dispatchAction} = useRichComponent(surface, component, basePath);
  const seats = p.seats ?? [];
  const rows = [...new Set(seats.map((seat) => seat.row))].sort((left, right) => left - right);
  const aisles = new Set(p.aislesAfter ?? []);

  return <section className="anu-rich-seatmap" aria-label={p.aircraftType ?? "Seat map"}>
    <div className="seatmap-toolbar">
      <strong>{p.aircraftType ?? "Seat map"}</strong>
      <div className="seatmap-legend" aria-label="Seat legend"><span><i className="available"/>Available</span><span><i className="selected"/>Selected</span><span><i className="unavailable"/>Unavailable</span></div>
    </div>
    <div className="aircraft-direction" aria-hidden="true"><span>FRONT</span><span>→</span></div>
    <div className="aircraft-cabin">
      {rows.map((row) => <div className="seat-column" key={row}>
        <b>{row}</b>
        {seats.filter((seat) => seat.row === row).map((seat) => <React.Fragment key={seat.seat}>
          <button
            type="button"
            disabled={["RESERVED", "UNAVAILABLE"].includes(seat.status)}
            className={`seat ${seat.status.toLowerCase()} ${seat.seat === p.selectedSeat ? "selected" : ""}`}
            aria-label={`Seat ${seat.seat}`}
            onClick={seat.selectAction ? () => dispatchAction(seat.selectAction) : undefined}
          >{seat.column}</button>
          {aisles.has(seat.column) && <span className="seat-aisle" aria-hidden="true"/>}
        </React.Fragment>)}
      </div>)}
    </div>
  </section>;
}
