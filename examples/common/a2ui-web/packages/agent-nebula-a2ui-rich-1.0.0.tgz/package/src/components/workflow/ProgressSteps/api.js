/** A2UI v1.0 schema for reusable workflow progress presentation. */
import {z} from "zod";
import {dynamic} from "../../../schema.js";

const progressStep = z.object({
  id: z.string(),
  label: z.string(),
  status: z.enum(["pending", "active", "complete", "error"]),
  message: z.string().optional(),
}).strict();

/** Rich Catalog API for ordered, data-bound workflow progress. */
export const api = {
  name: "ProgressSteps",
  schema: z.object({
    title: z.string().optional(),
    steps: dynamic(z.array(progressStep).min(1)),
  }).strict(),
};
