/** Trusted React renderer for the reusable Rich Catalog progress component. */
import React from "react";
import {useRichComponent} from "../../../binding.js";

/** Render semantic progress state; host applications own visual theme CSS. */
export function Renderer({surface, component, basePath = "/"}) {
  const {properties} = useRichComponent(surface, component, basePath);
  return (
    <section className="anu-rich-progress" aria-live="polite">
      {properties.title && <h3>{properties.title}</h3>}
      <ol>
        {(properties.steps ?? []).map((step) => (
          <li key={step.id} className={`progress-${step.status}`} data-status={step.status}>
            <span className="progress-indicator" aria-hidden="true"/>
            <div>
              <strong>{step.label}</strong>
              {step.message && <small>{step.message}</small>}
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
