/** Stable A2UI v1.0 Rich Catalog identifier used for renderer negotiation. */
export const RICH_CATALOG_ID = "https://agentnebula.ai/catalogs/a2ui/rich/v1/catalog.json";
