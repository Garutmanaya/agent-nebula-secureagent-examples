/** AUTO-GENERATED. */
import {api as a0} from "../components/bi/BarChart/api.js";
import {api as a1} from "../components/bi/DataTable/api.js";
import {api as a2} from "../components/bi/DonutChart/api.js";
import {api as a3} from "../components/bi/KPI/api.js";
import {api as a4} from "../components/bi/LineChart/api.js";
import {api as a5} from "../components/information/KeyValueGroup/api.js";
import {api as a6} from "../components/information/Metric/api.js";
import {api as a7} from "../components/information/MetricGroup/api.js";
import {api as a8} from "../components/information/StatusBadge/api.js";
import {api as a9} from "../components/itinerary/Itinerary/api.js";
import {api as a10} from "../components/itinerary/Timeline/api.js";
import {api as a11} from "../components/results/ActionBar/api.js";
import {api as a12} from "../components/results/DetailPanel/api.js";
import {api as a13} from "../components/results/ResultCard/api.js";
import {api as a14} from "../components/spatial/ParkingMap/api.js";
import {api as a15} from "../components/spatial/SeatMap/api.js";
import {api as a16} from "../components/workflow/ProgressSteps/api.js";
export const RICH_COMPONENT_APIS=[a0,a1,a2,a3,a4,a5,a6,a7,a8,a9,a10,a11,a12,a13,a14,a15,a16];
