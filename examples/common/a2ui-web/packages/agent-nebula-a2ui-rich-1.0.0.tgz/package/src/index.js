/** Public package API for the Agent Nebula A2UI Rich Catalog. */
import {Catalog} from "@a2ui/web_core/catalog";
import {RICH_CATALOG_ID} from "./constants.js";
import {RICH_COMPONENT_APIS} from "./generated/api-registry.js";
import {RICH_COMPONENT_RENDERERS} from "./generated/renderer-registry.js";
export {RICH_CATALOG_ID, RICH_COMPONENT_APIS, RICH_COMPONENT_RENDERERS};
export const RICH_CATALOG = new Catalog(RICH_CATALOG_ID, RICH_COMPONENT_APIS, [], undefined, "Reusable Agent Nebula enterprise, BI, itinerary, and spatial visualizations.", "1.0");
