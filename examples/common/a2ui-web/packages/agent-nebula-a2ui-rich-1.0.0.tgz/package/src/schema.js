/** Reusable schema helpers; these describe values, not UI composition. */
import {DataBindingSchema, FunctionCallSchema} from "@a2ui/web_core/v1_0";
import {z} from "zod";

export const dynamic = (schema) => z.union([schema, DataBindingSchema, FunctionCallSchema]);
export const dynamicString = dynamic(z.string());
export const dynamicNumber = dynamic(z.number());
export const dynamicBoolean = dynamic(z.boolean());
export const statusSchema = z.enum(["info", "success", "warning", "error", "neutral", "pending"]);
export const actionItemSchema = z.object({id:z.string(), label:z.string(), variant:z.enum(["primary","secondary","danger"]).optional(), disabled:z.boolean().optional()}).strict();
